#!/usr/bin/env python3
"""
EJERCICIO 1 - MANEJO DE ENTRADAS Y SALIDAS DIGITALES
=====================================================
ESQUELETO ADAPTABLE para el examen.

CONCEPTO: Un "personaje" se mueve entre LEDs (izquierda/derecha).
          Hay límites, si te sales => pierdes.

PINES USADOS (CAMBIAR SEGÚN ENUNCIADO):
  LEDs del juego  : 20, 21, 22, 23, 24   (el 22 es el centro)
  LED victoria    : 21  (ON = gana, OFF = pierde)  ← puede ser otro
  LED semáforo    : 27  (verde = pulsa ya)          ← puede ser otro
  Pulsador IZQ/RESET : 16   ← CAMBIAR si hace falta
  Pulsador DER       : 19   ← CAMBIAR si hace falta
  Pulsador RANDOM    : 26   ← CAMBIAR si hace falta (puede no existir)
"""

from imatpy import iMAT          # Librería de la placa iMAT (Raspberry Pi HAT)
import time
import random

# ──────────────────────────────────────────────
# 1. CONFIGURACIÓN GLOBAL  ← TOCA AQUÍ PRIMERO
# ──────────────────────────────────────────────

# Lista de LEDs que representan las posiciones del tablero (orden izquierda → derecha)
LEDS = [20, 21, 22, 23, 24]   # ← CAMBIAR si el enunciado usa otros pines

# Posición inicial del personaje (índice dentro de LEDS, 0 = más a la izquierda)
pos_inicial = 2                 # ← 2 = centro (LED 22). Cambiar si arranca en otro sitio

# Pulsadores  ← CAMBIAR según enunciado
BTN_IZQ    = 16   # Mover izquierda / RESET si has perdido
BTN_DER    = 19   # Mover derecha
BTN_RANDOM = 26   # Salto aleatorio (puede no existir en tu examen, comenta las líneas)

# LEDs auxiliares
LED_VICTORIA = 25  # ON = ganaste, OFF = perdiste   ← CAMBIAR
LED_SEMAFORO = 27  # Verde = puedes jugar            ← CAMBIAR (puede no existir)

# Rango del salto aleatorio  ← CAMBIAR si el enunciado dice otro rango
SALTO_MIN = -2
SALTO_MAX =  2

# ──────────────────────────────────────────────
# 2. INICIALIZACIÓN
# ──────────────────────────────────────────────

hat = iMAT()   # Crea el objeto que controla la placa

def inicializar():
    """Apaga todos los LEDs y enciende el de la posición inicial."""
    for led in LEDS:
        hat.LED(led, False)          # Apaga todos
    hat.LED(LED_VICTORIA, False)     # Apaga victoria
    # hat.LED(LED_SEMAFORO, False)   # ← Descomentar si hay semáforo


# ──────────────────────────────────────────────
# 3. FUNCIONES AUXILIARES
# ──────────────────────────────────────────────

def actualizar_leds(posicion):
    """
    Apaga todos los LEDs del tablero y enciende solo el de 'posicion'.
    posicion = índice (0..len(LEDS)-1)
    """
    for i, led in enumerate(LEDS):
        hat.LED(led, i == posicion)  # Enciende solo el de la posición actual


def boton_pulsado(btn):
    """
    Devuelve True en el FLANCO DE BAJADA del botón (pulsación).
    Versión POLLING (sin interrupciones).
    Úsala así:
        if boton_pulsado(BTN_DER):
            <haz algo>
    """
    if hat.BTN(btn) == 0:            # Botón presionado (activo a nivel bajo)
        time.sleep(0.05)             # Anti-rebote
        if hat.BTN(btn) == 0:        # Confirmamos que sigue pulsado
            while hat.BTN(btn) == 0: # Esperamos a que se suelte
                pass
            return True
    return False


def esperar_boton(btn, timeout=None):
    """
    Espera hasta que se pulse 'btn'.
    Si se pasa 'timeout' (segundos), devuelve False si se acaba el tiempo.
    Devuelve True si se pulsó, False si timeout.

    USO SIN TIMEOUT  : esperar_boton(BTN_DER)
    USO CON TIMEOUT  : if esperar_boton(BTN_DER, timeout=3): ...
    """
    t_inicio = time.time()
    while True:
        if boton_pulsado(btn):
            return True
        if timeout is not None and (time.time() - t_inicio) > timeout:
            return False
        time.sleep(0.01)             # Pequeña pausa para no saturar la CPU


# ──────────────────────────────────────────────
# 4. CONDICIONES DE VICTORIA / DERROTA
# ──────────────────────────────────────────────

def comprobar_victoria(posicion):
    """
    Define aquí cuándo GANA el jugador.
    EJEMPLO A: gana si llega al extremo derecho (posición final)
    EJEMPLO B: gana si pasa X veces por el centro
    Devuelve True si ha ganado.
    ← ADAPTAR AL ENUNCIADO
    """
    # ── EJEMPLO A: llegar al extremo derecho ──
    if posicion == len(LEDS) - 1:    # Posición más a la derecha
        return True

    # ── EJEMPLO B: pasar N veces por el centro (necesita contador externo) ──
    # if veces_en_centro >= 3:
    #     return True

    return False


def comprobar_derrota(posicion):
    """
    Define aquí cuándo PIERDE el jugador.
    EJEMPLO: salirse del rango de LEDs válidos.
    Devuelve True si ha perdido.
    ← ADAPTAR AL ENUNCIADO
    """
    if posicion < 0 or posicion >= len(LEDS):   # Fuera del tablero
        return True
    return False


def gestionar_victoria():
    """Acciones cuando el jugador GANA."""
    print("¡GANASTE!")
    hat.LED(LED_VICTORIA, True)      # Enciende LED de victoria
    # Aquí puedes añadir: actualizar contador, mostrar por consola, etc.


def gestionar_derrota():
    """
    Acciones cuando el jugador PIERDE.
    Espera a que se pulse el botón de reset para reiniciar.
    """
    print("PERDISTE. Pulsa el botón izquierdo para reiniciar.")
    hat.LED(LED_VICTORIA, False)     # Apaga LED de victoria (indica derrota)
    # Espera al botón de reset
    esperar_boton(BTN_IZQ)           # ← BTN de reset (puede ser otro)
    print("Reiniciando...")


# ──────────────────────────────────────────────
# 5. LÓGICA PRINCIPAL DEL JUEGO
# ──────────────────────────────────────────────

def jugar():
    """Bucle principal de una ronda."""
    posicion = pos_inicial           # ← Posición de inicio
    # veces_en_centro = 0           # ← Descomentar si necesitas contador

    inicializar()
    actualizar_leds(posicion)
    print(f"Posición inicial: LED {LEDS[posicion]}")

    while True:
        # ── Botón DERECHA ──────────────────────
        if boton_pulsado(BTN_DER):
            posicion += 1            # Mover a la derecha
            print(f"→ Derecha | LED {LEDS[posicion] if 0 <= posicion < len(LEDS) else 'FUERA'}")

        # ── Botón IZQUIERDA ────────────────────
        elif boton_pulsado(BTN_IZQ):
            posicion -= 1            # Mover a la izquierda
            print(f"← Izquierda | LED {LEDS[posicion] if 0 <= posicion < len(LEDS) else 'FUERA'}")

        # ── Botón RANDOM ───────────────────────
        elif boton_pulsado(BTN_RANDOM):
            salto = random.randint(SALTO_MIN, SALTO_MAX)
            posicion += salto
            print(f"🎲 Salto aleatorio: {salto:+d} | LED {LEDS[posicion] if 0 <= posicion < len(LEDS) else 'FUERA'}")

        else:
            continue                 # Ningún botón pulsado → vuelve al inicio del while

        # ── Comprobar derrota ──────────────────
        if comprobar_derrota(posicion):
            gestionar_derrota()
            return False             # Ronda terminada (derrota)

        # ── Actualizar LEDs ────────────────────
        actualizar_leds(posicion)

        # ── Comprobar victoria ─────────────────
        if comprobar_victoria(posicion):
            gestionar_victoria()
            return True              # Ronda terminada (victoria)


# ──────────────────────────────────────────────
# 6. PUNTO DE ENTRADA
# ──────────────────────────────────────────────

if __name__ == "__main__":
    print("=== INICIO DEL JUEGO ===")
    while True:
        resultado = jugar()
        print("Victoria!" if resultado else "Derrota.")
        # ← Puedes añadir aquí un contador de puntuación
        time.sleep(0.5)
